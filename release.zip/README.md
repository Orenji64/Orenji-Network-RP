# Orenji Network RP
The resource pack repository for developing and hosting the files

## Credits
* [Me (Orenji64)](https://orenji64.net) - Custom content
* [Mojang](https://minecraft.net) - Some base textures from Minecraft
* [Vanilla Tweaks](https://vanillatweaks.net) - Enhancement features
