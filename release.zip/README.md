# Orenji Network RP
The resource pack repository for developing and hosting the files

## Credits
* [Me (Orenji64)](https://orenji64.net) - Custom content
* [Vanilla Tweaks](https://vanillatweaks.net) - Enhancement features
